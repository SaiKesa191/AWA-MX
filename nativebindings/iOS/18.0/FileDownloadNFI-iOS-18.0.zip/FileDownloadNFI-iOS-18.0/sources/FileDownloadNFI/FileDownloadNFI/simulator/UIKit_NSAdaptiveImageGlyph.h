#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_NSAdaptiveImageGlyph_symbols(JSContext*);
@protocol NSAdaptiveImageGlyphInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_, CTAdaptiveImageProvidingInstanceExports_>
@property (readonly) NSData * imageContent;
@property (readonly) NSString * contentIdentifier;
@property (readonly,copy) NSString * contentDescription;
JSExportAs(initWithImageContent,
-(id) jsinitWithImageContent: (NSData *) imageContent );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
@end
@protocol NSAdaptiveImageGlyphClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_, CTAdaptiveImageProvidingClassExports_>
+(UTType *) contentType;
@end
@protocol NSAttributedStringNSAttributedStringAdaptiveImageGlyphConveniencesCategoryInstanceExports<JSExport>
@end
@protocol NSAttributedStringNSAttributedStringAdaptiveImageGlyphConveniencesCategoryClassExports<JSExport>
+(id) attributedStringWithAdaptiveImageGlyph: (NSAdaptiveImageGlyph *) adaptiveImageGlyph attributes: (NSDictionary *) attributes ;
@end
#pragma clang diagnostic pop