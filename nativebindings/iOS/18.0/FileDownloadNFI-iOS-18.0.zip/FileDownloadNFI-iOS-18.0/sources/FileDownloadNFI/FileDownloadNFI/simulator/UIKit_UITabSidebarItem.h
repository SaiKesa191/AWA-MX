#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UITabSidebarItem_symbols(JSContext*);
@protocol UITabSidebarItemInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (readonly,nonatomic,strong) UITab * tab;
@property (readonly,nonatomic,strong) UIAction * action;
@property (readonly,nonatomic,strong) UICellConfigurationState * configurationState;
@property (copy,nonatomic) id contentConfiguration;
@property (copy,nonatomic) UIBackgroundConfiguration * backgroundConfiguration;
@property (copy,nonatomic) NSArray * accessories;
-(UIListContentConfiguration *) defaultContentConfiguration;
-(UIBackgroundConfiguration *) defaultBackgroundConfiguration;
@end
@protocol UITabSidebarItemClassExports<JSExport, NSCopyingClassExports_>
+(id) itemFromRequest: (UITabSidebarItemRequest *) request ;
@end
@protocol UITabSidebarItemRequestInstanceExports<JSExport>
@property (readonly,nonatomic) UITab * tab;
@property (readonly,nonatomic) UIAction * action;
@end
@protocol UITabSidebarItemRequestClassExports<JSExport>
@end
#pragma clang diagnostic pop