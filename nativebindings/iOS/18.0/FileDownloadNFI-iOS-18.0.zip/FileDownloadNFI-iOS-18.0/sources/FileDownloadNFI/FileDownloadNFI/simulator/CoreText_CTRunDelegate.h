#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_CoreText_CTRunDelegate_symbols(JSContext*);
@protocol CTAdaptiveImageProvidingInstanceExports_<JSExport>
@end
@protocol CTAdaptiveImageProvidingClassExports_<JSExport>
@end
#pragma clang diagnostic pop