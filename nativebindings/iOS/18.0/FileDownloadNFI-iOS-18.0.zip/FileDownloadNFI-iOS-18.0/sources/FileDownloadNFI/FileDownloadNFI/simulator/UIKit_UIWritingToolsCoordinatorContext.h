#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIWritingToolsCoordinatorContext_symbols(JSContext*);
@protocol UIWritingToolsCoordinatorContextInstanceExports<JSExport>
@property (readonly,copy,nonatomic) NSAttributedString * attributedString;
@property (readonly,nonatomic) NSRange range;
@property (readonly,nonatomic,strong) NSUUID * identifier;
@property (readonly,nonatomic) NSRange resolvedRange;
JSExportAs(initWithAttributedStringRange,
-(id) jsinitWithAttributedString: (NSAttributedString *) attributedString range: (NSRange) range );
@end
@protocol UIWritingToolsCoordinatorContextClassExports<JSExport>
@end
#pragma clang diagnostic pop