#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UICalendarSelectionWeekOfYear_symbols(JSContext*);
@protocol UICalendarSelectionWeekOfYearInstanceExports<JSExport>
@property (copy,nonatomic) NSDateComponents * selectedWeekOfYear;
@property (readonly,nonatomic,weak) id delegate;
-(void) setSelectedWeekOfYear: (NSDateComponents *) selectedWeekOfYear animated: (BOOL) animated ;
JSExportAs(initWithDelegate,
-(id) jsinitWithDelegate: (id) delegate );
@end
@protocol UICalendarSelectionWeekOfYearClassExports<JSExport>
@end
@protocol UICalendarSelectionWeekOfYearDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) weekOfYearSelection: (UICalendarSelectionWeekOfYear *) selection didSelectWeekOfYear: (NSDateComponents *) weekOfYearComponents ;
-(BOOL) weekOfYearSelection: (UICalendarSelectionWeekOfYear *) selection canSelectWeekOfYear: (NSDateComponents *) weekOfYearComponents ;
@end
@protocol UICalendarSelectionWeekOfYearDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop