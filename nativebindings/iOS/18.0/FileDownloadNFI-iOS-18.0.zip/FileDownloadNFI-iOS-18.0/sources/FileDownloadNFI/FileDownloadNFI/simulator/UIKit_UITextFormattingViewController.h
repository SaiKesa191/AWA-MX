#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UITextFormattingViewController_symbols(JSContext*);
@protocol UITextFormattingViewControllerInstanceExports<JSExport>
@property (readonly,copy,nonatomic) UITextFormattingViewControllerConfiguration * configuration;
@property (copy,nonatomic) UITextFormattingViewControllerFormattingDescriptor * formattingDescriptor;
@property (nonatomic,weak) id delegate;
-(id) jsinit;
JSExportAs(initWithConfiguration,
-(id) jsinitWithConfiguration: (UITextFormattingViewControllerConfiguration *) configuration );
@end
@protocol UITextFormattingViewControllerClassExports<JSExport>
@end
@protocol UITextFormattingViewControllerDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) textFormattingViewController: (UITextFormattingViewController *) viewController didChangeValue: (UITextFormattingViewControllerChangeValue *) changeValue ;
-(BOOL) textFormattingViewController: (UITextFormattingViewController *) viewController shouldPresentFontPicker: (UIFontPickerViewController *) fontPicker ;
-(BOOL) textFormattingViewController: (UITextFormattingViewController *) viewController shouldPresentColorPicker: (UIColorPickerViewController *) colorPicker ;
-(void) textFormattingDidFinish: (UITextFormattingViewController *) viewController ;
@end
@protocol UITextFormattingViewControllerDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop