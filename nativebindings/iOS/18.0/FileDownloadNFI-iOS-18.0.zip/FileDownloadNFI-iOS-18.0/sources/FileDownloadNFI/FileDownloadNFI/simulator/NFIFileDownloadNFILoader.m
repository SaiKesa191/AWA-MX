#import "allincludes.h"
#import <JavaScriptCore/JavaScriptCore.h>
void loadNFIFileDownloadNFIModules(JSContext* context)
{
	load_FileDownloadNFI_DownloadViewController_symbols(context);
	load_FileDownloadNFI_FilePreviewViewController_symbols(context);
	load_FileDownloadNFI_FileDownloadNFI_symbols(context);
}

JSValue* extractNFIFileDownloadNFIStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context)
{
    
    return nil;
}

BOOL setNFIFileDownloadNFIStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation)
{
    
    return NO;
}

