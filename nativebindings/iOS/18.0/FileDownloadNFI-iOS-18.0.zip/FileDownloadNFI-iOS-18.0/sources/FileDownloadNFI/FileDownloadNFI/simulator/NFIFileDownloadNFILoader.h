#import <JavaScriptCore/JavaScriptCore.h>

void loadNFIFileDownloadNFIModules(JSContext* context);
JSValue* extractNFIFileDownloadNFIStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFIFileDownloadNFIStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);
