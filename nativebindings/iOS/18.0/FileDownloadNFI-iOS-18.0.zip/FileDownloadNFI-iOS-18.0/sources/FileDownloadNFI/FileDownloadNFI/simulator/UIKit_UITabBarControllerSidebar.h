#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UITabBarControllerSidebar_symbols(JSContext*);
@protocol UITabSidebarScrollTargetInstanceExports<JSExport>
@end
@protocol UITabSidebarScrollTargetClassExports<JSExport>
+(id) targetForHeader;
+(id) targetForFooter;
+(id) targetForTab: (UITab *) tab ;
@end
@protocol UITabBarControllerSidebarInstanceExports<JSExport>
@property (nonatomic,weak) id delegate;
@property (getter=isHidden,assign,nonatomic) BOOL hidden;
@property (assign,nonatomic) UITabBarControllerSidebarLayout preferredLayout;
@property (copy,nonatomic) id headerContentConfiguration;
@property (copy,nonatomic) id footerContentConfiguration;
@property (nonatomic,strong) UIView * bottomBarView;
-(void) scrollToTarget: (UITabSidebarScrollTarget *) target animated: (BOOL) animated ;
-(void) reconfigureItemForTab: (UITab *) tab ;
@end
@protocol UITabBarControllerSidebarClassExports<JSExport>
@end
@protocol UITabBarControllerSidebarAnimatingInstanceExports_<JSExport, NSObjectInstanceExports_>
JSExportAs(addAnimations,
-(void) jsaddAnimations: (JSValue *) animations );
JSExportAs(addCompletion,
-(void) jsaddCompletion: (JSValue *) completion );
@end
@protocol UITabBarControllerSidebarAnimatingClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol UITabBarControllerSidebarDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) tabBarController: (UITabBarController *) tabBarController sidebarVisibilityWillChange: (UITabBarControllerSidebar *) sidebar animator: (id) animator ;
-(UITabSidebarItem *) tabBarController: (UITabBarController *) tabBarController sidebar: (UITabBarControllerSidebar *) sidebar itemForRequest: (UITabSidebarItemRequest *) request ;
-(void) tabBarController: (UITabBarController *) tabBarController sidebar: (UITabBarControllerSidebar *) sidebar updateItem: (UITabSidebarItem *) item ;
-(void) tabBarController: (UITabBarController *) tabBarController sidebar: (UITabBarControllerSidebar *) sidebar willBeginDisplayingTab: (__kindof UITab *) tab ;
-(void) tabBarController: (UITabBarController *) tabBarController sidebar: (UITabBarControllerSidebar *) sidebar didEndDisplayingTab: (__kindof UITab *) tab ;
-(UISwipeActionsConfiguration *) tabBarController: (UITabBarController *) tabBarController sidebar: (UITabBarControllerSidebar *) sidebar leadingSwipeActionsConfigurationForTab: (__kindof UITab *) tab ;
-(UISwipeActionsConfiguration *) tabBarController: (UITabBarController *) tabBarController sidebar: (UITabBarControllerSidebar *) sidebar trailingSwipeActionsConfigurationForTab: (__kindof UITab *) tab ;
-(UIContextMenuConfiguration *) tabBarController: (UITabBarController *) tabBarController sidebar: (UITabBarControllerSidebar *) sidebar contextMenuConfigurationForTab: (__kindof UITab *) tab ;
@end
@protocol UITabBarControllerSidebarDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop