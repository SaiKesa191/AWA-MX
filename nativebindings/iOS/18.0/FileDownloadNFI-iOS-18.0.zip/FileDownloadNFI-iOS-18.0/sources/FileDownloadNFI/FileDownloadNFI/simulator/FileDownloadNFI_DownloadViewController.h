#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_FileDownloadNFI_DownloadViewController_symbols(JSContext*);
@protocol DownloadViewControllerInstanceExports<JSExport>
-(void) base64String: (NSString *) base64 fileName: (NSString *) fileName ;
@end
@protocol DownloadViewControllerClassExports<JSExport>
@end
#pragma clang diagnostic pop