#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UITextFormattingViewControllerConfiguration_symbols(JSContext*);
@protocol UITextFormattingViewControllerConfigurationInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,copy,nonatomic) NSArray * groups;
@property (copy,nonatomic) NSArray * formattingStyles;
@property (copy,nonatomic) UIFontPickerViewControllerConfiguration * fontPickerConfiguration;
-(id) jsinit;
JSExportAs(initWithGroups,
-(id) jsinitWithGroups: (NSArray *) groups );
@end
@protocol UITextFormattingViewControllerConfigurationClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
@end
#pragma clang diagnostic pop