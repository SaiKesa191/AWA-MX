#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_NSTextContainer_symbols(JSContext*);
@protocol NSTextContainerInstanceExports<JSExport, NSSecureCodingInstanceExports_>
@property (readonly,nonatomic,weak) NSTextLayoutManager * textLayoutManager;
@property (nonatomic) CGSize size;
@property (nonatomic) NSLineBreakMode lineBreakMode;
@property (nonatomic) CGFloat lineFragmentPadding;
@property (nonatomic) NSUInteger maximumNumberOfLines;
@property (getter=isSimpleRectangularTextContainer,readonly,nonatomic) BOOL simpleRectangularTextContainer;
@property (nonatomic) BOOL widthTracksTextView;
@property (nonatomic) BOOL heightTracksTextView;
JSExportAs(initWithSize,
-(id) jsinitWithSize: (CGSize) size );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
@end
@protocol NSTextContainerClassExports<JSExport, NSSecureCodingClassExports_>
@end
@protocol NSTextContainerAnonCategoryInstanceExports<JSExport, NSTextLayoutOrientationProviderInstanceExports_>
@property (assign,nonatomic) NSLayoutManager * layoutManager;
@property (copy,nonatomic) NSArray * exclusionPaths;
-(void) replaceLayoutManager: (NSLayoutManager *) newLayoutManager ;
@end
@protocol NSTextContainerAnonCategoryClassExports<JSExport, NSTextLayoutOrientationProviderClassExports_>
@end
#pragma clang diagnostic pop