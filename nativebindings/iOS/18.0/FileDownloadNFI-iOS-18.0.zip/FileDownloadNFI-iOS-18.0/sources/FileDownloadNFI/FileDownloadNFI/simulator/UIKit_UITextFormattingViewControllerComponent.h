#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UITextFormattingViewControllerComponent_symbols(JSContext*);
@protocol UITextFormattingViewControllerComponentInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,nonatomic) UITextFormattingViewControllerComponentKey componentKey;
@property (readonly,nonatomic) UITextFormattingViewControllerComponentSize preferredSize;
JSExportAs(initWithComponentKeyPreferredSize,
-(id) jsinitWithComponentKey: (UITextFormattingViewControllerComponentKey) componentKey preferredSize: (UITextFormattingViewControllerComponentSize) preferredSize );
@end
@protocol UITextFormattingViewControllerComponentClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
@end
@protocol UITextFormattingViewControllerComponentGroupInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,copy,nonatomic) NSArray * components;
JSExportAs(initWithComponents,
-(id) jsinitWithComponents: (NSArray *) components );
@end
@protocol UITextFormattingViewControllerComponentGroupClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
@end
#pragma clang diagnostic pop