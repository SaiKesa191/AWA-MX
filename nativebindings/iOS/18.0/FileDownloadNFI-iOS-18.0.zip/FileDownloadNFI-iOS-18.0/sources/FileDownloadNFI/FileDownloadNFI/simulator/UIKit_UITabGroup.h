#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UITabGroup_symbols(JSContext*);
@protocol UITabGroupInstanceExports<JSExport>
@property (nonatomic,strong) UITab * selectedChild;
@property (copy,nonatomic) NSString * defaultChildIdentifier;
@property (copy,nonatomic) NSArray * children;
@property (copy,nonatomic) NSArray * displayOrderIdentifiers;
@property (assign,nonatomic) BOOL allowsReordering;
@property (readonly,nonatomic,strong) NSArray * displayOrder;
@property (nonatomic,strong) UINavigationController * managingNavigationController;
@property (copy,nonatomic) NSArray * sidebarActions;
@property (assign,nonatomic) UITabGroupSidebarAppearance sidebarAppearance;
-(UITab *) tabForIdentifier: (NSString *) identifier ;
JSExportAs(initWithTitleImageIdentifierChildrenViewControllerProvider,
-(id) jsinitWithTitle: (NSString *) title image: (UIImage *) image identifier: (NSString *) identifier children: (NSArray *) children viewControllerProvider: (JSValue *) viewControllerProvider );
@end
@protocol UITabGroupClassExports<JSExport>
@end
#pragma clang diagnostic pop