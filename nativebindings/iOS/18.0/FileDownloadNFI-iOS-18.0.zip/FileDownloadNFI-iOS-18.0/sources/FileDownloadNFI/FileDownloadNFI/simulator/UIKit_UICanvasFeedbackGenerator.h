#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UICanvasFeedbackGenerator_symbols(JSContext*);
@protocol UICanvasFeedbackGeneratorInstanceExports<JSExport>
-(void) alignmentOccurredAtLocation: (CGPoint) location ;
-(void) pathCompletedAtLocation: (CGPoint) location ;
@end
@protocol UICanvasFeedbackGeneratorClassExports<JSExport>
@end
#pragma clang diagnostic pop