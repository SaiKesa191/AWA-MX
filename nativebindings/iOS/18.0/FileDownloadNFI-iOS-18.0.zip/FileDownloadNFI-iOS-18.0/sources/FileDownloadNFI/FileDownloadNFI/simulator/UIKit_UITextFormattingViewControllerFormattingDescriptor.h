#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UITextFormattingViewControllerFormattingDescriptor_symbols(JSContext*);
@protocol UITextFormattingViewControllerFormattingDescriptorInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (copy,nonatomic) NSArray * fonts;
@property (copy,nonatomic) NSArray * textColors;
@property (nonatomic) CGFloat lineHeight;
@property (nonatomic) BOOL underlinePresent;
@property (nonatomic) BOOL strikethroughPresent;
@property (copy,nonatomic) NSSet * textAlignments;
@property (copy,nonatomic) NSSet * textLists;
@property (copy,nonatomic) NSSet * highlights;
@property (copy,nonatomic) NSString * formattingStyleKey;
-(id) jsinit;
JSExportAs(initWithStringRange,
-(id) jsinitWithString: (NSAttributedString *) string range: (NSRange) range );
JSExportAs(initWithAttributes,
-(id) jsinitWithAttributes: (NSDictionary *) attributes );
@end
@protocol UITextFormattingViewControllerFormattingDescriptorClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
@end
#pragma clang diagnostic pop