#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIInputViewController_symbols(JSContext*);
@protocol UIInputViewControllerInstanceExports<JSExport, UITextInputDelegateInstanceExports_>
@property (nonatomic,strong) UIInputView * inputView;
@property (readonly,nonatomic) id textDocumentProxy;
@property (copy,nonatomic) NSString * primaryLanguage;
@property (nonatomic) BOOL hasDictationKey;
@property (readonly,nonatomic) BOOL hasFullAccess;
@property (readonly,nonatomic) BOOL needsInputModeSwitchKey;
-(void) dismissKeyboard;
-(void) advanceToNextInputMode;
-(void) handleInputModeListFromView: (UIView *) view withEvent: (UIEvent *) event ;
JSExportAs(requestSupplementaryLexiconWithCompletion,
-(void) jsrequestSupplementaryLexiconWithCompletion: (JSValue *) completionHandler );
@end
@protocol UIInputViewControllerClassExports<JSExport, UITextInputDelegateClassExports_>
@end
@protocol UITextDocumentProxyInstanceExports_<JSExport, UIKeyInputInstanceExports_>
@property (readonly,nonatomic) NSString * documentContextBeforeInput;
@property (readonly,nonatomic) NSString * documentContextAfterInput;
@property (readonly,nonatomic) NSString * selectedText;
@property (readonly,nonatomic) UITextInputMode * documentInputMode;
@property (readonly,copy,nonatomic) NSUUID * documentIdentifier;
-(void) adjustTextPositionByCharacterOffset: (NSInteger) offset ;
-(void) setMarkedText: (NSString *) markedText selectedRange: (NSRange) selectedRange ;
-(void) unmarkText;
@end
@protocol UITextDocumentProxyClassExports_<JSExport, UIKeyInputClassExports_>
@end
#pragma clang diagnostic pop