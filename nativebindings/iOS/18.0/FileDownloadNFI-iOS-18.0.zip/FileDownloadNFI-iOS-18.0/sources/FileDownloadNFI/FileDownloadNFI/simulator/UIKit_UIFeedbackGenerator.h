#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIFeedbackGenerator_symbols(JSContext*);
@protocol UIFeedbackGeneratorInstanceExports<JSExport>
-(id) jsinit;
-(void) prepare;
@end
@protocol UIFeedbackGeneratorClassExports<JSExport>
+(id) feedbackGeneratorForView: (UIView *) view ;
@end
@protocol UIFeedbackGeneratorAnonCategoryInstanceExports<JSExport, UIInteractionInstanceExports_>
@end
@protocol UIFeedbackGeneratorAnonCategoryClassExports<JSExport, UIInteractionClassExports_>
@end
#pragma clang diagnostic pop