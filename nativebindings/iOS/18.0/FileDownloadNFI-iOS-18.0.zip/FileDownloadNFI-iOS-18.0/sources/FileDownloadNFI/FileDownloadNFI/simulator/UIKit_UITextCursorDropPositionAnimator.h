#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UITextCursorDropPositionAnimator_symbols(JSContext*);
@protocol UITextCursorDropPositionAnimatorInstanceExports<JSExport>
@property (readonly,nonatomic) UIView * cursorView;
@property (readonly,nonatomic) UIView * textInput;
JSExportAs(initWithTextCursorViewTextInput,
-(id) jsinitWithTextCursorView: (UIView *) cursorView textInput: (UIView *) textInput );
-(void) setCursorVisible: (BOOL) visible animated: (BOOL) animated ;
-(void) placeCursorAtPosition: (UITextPosition *) position animated: (BOOL) animated ;
JSExportAs(animateAlongsideChangesCompletion,
-(void) jsanimateAlongsideChanges: (JSValue *) animation completion: (JSValue *) completion );
@end
@protocol UITextCursorDropPositionAnimatorClassExports<JSExport>
@end
#pragma clang diagnostic pop