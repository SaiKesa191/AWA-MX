#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UITextSelectionHighlightView_symbols(JSContext*);
@protocol UITextSelectionHighlightViewInstanceExports_<JSExport, UICoordinateSpaceInstanceExports_>
@property (nonatomic,strong) NSArray * selectionRects;
@end
@protocol UITextSelectionHighlightViewClassExports_<JSExport, UICoordinateSpaceClassExports_>
@end
#pragma clang diagnostic pop