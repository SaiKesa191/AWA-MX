#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIImpactFeedbackGenerator_symbols(JSContext*);
@protocol UIImpactFeedbackGeneratorInstanceExports<JSExport>
-(void) impactOccurred;
-(void) impactOccurredAtLocation: (CGPoint) location ;
-(void) impactOccurredWithIntensity: (CGFloat) intensity ;
-(void) impactOccurredWithIntensity: (CGFloat) intensity atLocation: (CGPoint) location ;
JSExportAs(initWithStyle,
-(id) jsinitWithStyle: (UIImpactFeedbackStyle) style );
@end
@protocol UIImpactFeedbackGeneratorClassExports<JSExport>
+(id) feedbackGeneratorWithStyle: (UIImpactFeedbackStyle) style forView: (UIView *) view ;
@end
#pragma clang diagnostic pop