#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIUpdateActionPhase_symbols(JSContext*);
@protocol UIUpdateActionPhaseInstanceExports<JSExport>
@end
@protocol UIUpdateActionPhaseClassExports<JSExport>
+(UIUpdateActionPhase *) afterUpdateScheduled;
+(UIUpdateActionPhase *) beforeEventDispatch;
+(UIUpdateActionPhase *) afterEventDispatch;
+(UIUpdateActionPhase *) beforeCADisplayLinkDispatch;
+(UIUpdateActionPhase *) afterCADisplayLinkDispatch;
+(UIUpdateActionPhase *) beforeCATransactionCommit;
+(UIUpdateActionPhase *) afterCATransactionCommit;
+(UIUpdateActionPhase *) beforeLowLatencyEventDispatch;
+(UIUpdateActionPhase *) afterLowLatencyEventDispatch;
+(UIUpdateActionPhase *) beforeLowLatencyCATransactionCommit;
+(UIUpdateActionPhase *) afterLowLatencyCATransactionCommit;
+(UIUpdateActionPhase *) afterUpdateComplete;
@end
#pragma clang diagnostic pop