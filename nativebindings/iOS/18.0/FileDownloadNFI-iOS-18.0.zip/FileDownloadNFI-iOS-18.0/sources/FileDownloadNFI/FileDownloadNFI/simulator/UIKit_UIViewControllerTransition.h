#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIViewControllerTransition_symbols(JSContext*);
@protocol UIViewControllerTransitionInstanceExports<JSExport>
@end
@protocol UIViewControllerTransitionClassExports<JSExport>
JSExportAs(zoomWithOptionsSourceViewProvider,
+(id) jszoomWithOptions: (UIZoomTransitionOptions *) options sourceViewProvider: (JSValue *) sourceViewProvider );
+(id) coverVerticalTransition;
+(id) flipHorizontalTransition;
+(id) crossDissolveTransition;
+(id) partialCurlTransition;
@end
@protocol UIZoomTransitionSourceViewProviderContextInstanceExports<JSExport>
@property (readonly,nonatomic,strong) UIViewController * sourceViewController;
@property (readonly,nonatomic,strong) UIViewController * zoomedViewController;
@end
@protocol UIZoomTransitionSourceViewProviderContextClassExports<JSExport>
@end
#pragma clang diagnostic pop