#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UITextFormattingViewControllerChangeValue_symbols(JSContext*);
@protocol UITextFormattingViewControllerChangeValueInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,nonatomic) UITextFormattingViewControllerChangeType changeType;
@property (readonly,copy,nonatomic) NSString * formattingStyleKey;
@property (readonly,copy,nonatomic) UIFont * font;
@property (readonly,copy,nonatomic) UIColor * color;
@property (readonly,copy,nonatomic) NSNumber * numberValue;
@property (readonly,copy,nonatomic) UITextFormattingViewControllerTextList textList;
@property (readonly,nonatomic) NSTextAlignment textAlignment;
@property (readonly,copy,nonatomic) UITextFormattingViewControllerHighlight highlight;
@end
@protocol UITextFormattingViewControllerChangeValueClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
@end
#pragma clang diagnostic pop