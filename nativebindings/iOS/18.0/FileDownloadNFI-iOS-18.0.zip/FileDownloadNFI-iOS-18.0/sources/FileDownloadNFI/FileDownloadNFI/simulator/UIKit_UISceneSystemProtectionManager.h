#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UISceneSystemProtectionManager_symbols(JSContext*);
@protocol UISceneSystemProtectionManagerInstanceExports<JSExport>
@property (getter=isUserAuthenticationEnabled,readonly) BOOL userAuthenticationEnabled;
@end
@protocol UISceneSystemProtectionManagerClassExports<JSExport>
@end
@protocol UISceneSystemProtectionCategoryInstanceExports<JSExport>
@property (readonly,nonatomic) UISceneSystemProtectionManager * systemProtectionManager;
@end
@protocol UISceneSystemProtectionCategoryClassExports<JSExport>
@end
#pragma clang diagnostic pop