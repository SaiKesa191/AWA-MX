#import <JavaScriptCore/JavaScriptCore.h>

void loadNFIExcelUploadFileNFIModules(JSContext* context);
JSValue* extractNFIExcelUploadFileNFIStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFIExcelUploadFileNFIStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);
