#import <JavaScriptCore/JavaScriptCore.h>

void loadNFIPDFDownloadNFIModules(JSContext* context);
JSValue* extractNFIPDFDownloadNFIStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFIPDFDownloadNFIStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);
