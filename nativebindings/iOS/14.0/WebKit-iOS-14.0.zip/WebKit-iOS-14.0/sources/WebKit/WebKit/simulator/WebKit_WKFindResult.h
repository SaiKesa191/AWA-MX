#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_WebKit_WKFindResult_symbols(JSContext*);
@protocol WKFindResultInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (readonly,nonatomic) BOOL matchFound;
@end
@protocol WKFindResultClassExports<JSExport, NSCopyingClassExports_>
@end
#pragma clang diagnostic pop