#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
@implementation WKWebView (Exports)
-(void) jscreatePDFWithConfiguration: (WKPDFConfiguration *) pdfConfiguration completionHandler: (JSValue *) completionHandler 
{
	void (^ completionHandler_)(NSData * , NSError * ) = nil;
	if (!completionHandler.isUndefined) {
		completionHandler_ = ^void(NSData * arg0, NSError * arg1) {
			JSContext* __jsContext = completionHandler.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: (arg0 ? [JSValue valueWithObject: arg0 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			[parameters addObject: (arg1 ? [JSValue valueWithObject: arg1 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			callJSFunction(__jsContext, completionHandler, self, parameters);
		};
	}
	[self createPDFWithConfiguration: pdfConfiguration completionHandler: completionHandler_ ];
}
-(void) jsevaluateJavaScript: (NSString *) javaScriptString inFrame: (WKFrameInfo *) frame inContentWorld: (WKContentWorld *) contentWorld completionHandler: (JSValue *) completionHandler 
{
	void (^ completionHandler_)(id , NSError * ) = nil;
	if (!completionHandler.isUndefined) {
		completionHandler_ = ^void(id arg0, NSError * arg1) {
			JSContext* __jsContext = completionHandler.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: (arg0 ? [JSValue valueWithObject: arg0 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			[parameters addObject: (arg1 ? [JSValue valueWithObject: arg1 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			callJSFunction(__jsContext, completionHandler, self, parameters);
		};
	}
	[self evaluateJavaScript: javaScriptString inFrame: frame inContentWorld: contentWorld completionHandler: completionHandler_ ];
}
-(void) jscreateWebArchiveDataWithCompletionHandler: (JSValue *) completionHandler 
{
	void (^ completionHandler_)(NSData * , NSError * ) = nil;
	if (!completionHandler.isUndefined) {
		completionHandler_ = ^void(NSData * arg0, NSError * arg1) {
			JSContext* __jsContext = completionHandler.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: (arg0 ? [JSValue valueWithObject: arg0 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			[parameters addObject: (arg1 ? [JSValue valueWithObject: arg1 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			callJSFunction(__jsContext, completionHandler, self, parameters);
		};
	}
	[self createWebArchiveDataWithCompletionHandler: completionHandler_ ];
}
-(id) jsinitWithCoder: (NSCoder *) coder 
{
	id resultVal__;
	resultVal__ = [[self initWithCoder: coder ] autorelease];
	return resultVal__;
}
-(void) jsfindString: (NSString *) string withConfiguration: (WKFindConfiguration *) configuration completionHandler: (JSValue *) completionHandler 
{
	void (^ completionHandler_)(WKFindResult * ) = nil;
	if (!completionHandler.isUndefined) {
		completionHandler_ = ^void(WKFindResult * arg0) {
			JSContext* __jsContext = completionHandler.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: (arg0 ? [JSValue valueWithObject: arg0 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			callJSFunction(__jsContext, completionHandler, self, parameters);
		};
	}
	[self findString: string withConfiguration: configuration completionHandler: completionHandler_ ];
}
-(void) jstakeSnapshotWithConfiguration: (WKSnapshotConfiguration *) snapshotConfiguration completionHandler: (JSValue *) completionHandler 
{
	void (^ completionHandler_)(UIImage * , NSError * ) = nil;
	if (!completionHandler.isUndefined) {
		completionHandler_ = ^void(UIImage * arg0, NSError * arg1) {
			JSContext* __jsContext = completionHandler.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: (arg0 ? [JSValue valueWithObject: arg0 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			[parameters addObject: (arg1 ? [JSValue valueWithObject: arg1 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			callJSFunction(__jsContext, completionHandler, self, parameters);
		};
	}
	[self takeSnapshotWithConfiguration: snapshotConfiguration completionHandler: completionHandler_ ];
}
-(id) jsinitWithFrame: (CGRect) frame configuration: (WKWebViewConfiguration *) configuration 
{
	id resultVal__;
	resultVal__ = [[self initWithFrame: frame configuration: configuration ] autorelease];
	return resultVal__;
}
-(void) jscallAsyncJavaScript: (NSString *) functionBody arguments: (NSDictionary *) arguments inFrame: (WKFrameInfo *) frame inContentWorld: (WKContentWorld *) contentWorld completionHandler: (JSValue *) completionHandler 
{
	void (^ completionHandler_)(id , NSError * ) = nil;
	if (!completionHandler.isUndefined) {
		completionHandler_ = ^void(id arg0, NSError * arg1) {
			JSContext* __jsContext = completionHandler.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: (arg0 ? [JSValue valueWithObject: arg0 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			[parameters addObject: (arg1 ? [JSValue valueWithObject: arg1 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			callJSFunction(__jsContext, completionHandler, self, parameters);
		};
	}
	[self callAsyncJavaScript: functionBody arguments: arguments inFrame: frame inContentWorld: contentWorld completionHandler: completionHandler_ ];
}
-(void) jsevaluateJavaScript: (NSString *) javaScriptString completionHandler: (JSValue *) completionHandler 
{
	void (^ completionHandler_)(id , NSError * ) = nil;
	if (!completionHandler.isUndefined) {
		completionHandler_ = ^void(id arg0, NSError * arg1) {
			JSContext* __jsContext = completionHandler.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: (arg0 ? [JSValue valueWithObject: arg0 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			[parameters addObject: (arg1 ? [JSValue valueWithObject: arg1 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			callJSFunction(__jsContext, completionHandler, self, parameters);
		};
	}
	[self evaluateJavaScript: javaScriptString completionHandler: completionHandler_ ];
}
@end
static void addProtocols()
{
	class_addProtocol([WKWebView class], @protocol(WKWebViewInstanceExports));
	class_addProtocol([WKWebView class], @protocol(WKWebViewClassExports));
	class_addProtocol([WKWebView class], @protocol(WKWebViewWKDeprecatedCategoryInstanceExports));
	class_addProtocol([WKWebView class], @protocol(WKWebViewWKDeprecatedCategoryClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
}
void load_WebKit_WKWebView_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
