#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
static void addProtocols()
{
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
	context[@"WKNavigationActionPolicyCancel"] = @0L;
	context[@"WKNavigationActionPolicyAllow"] = @1L;

	context[@"WKNavigationResponsePolicyCancel"] = @0L;
	context[@"WKNavigationResponsePolicyAllow"] = @1L;

}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
}
void WebKit_WKNavigationDelegateProtocols()
{
	(void)@protocol(WKNavigationDelegate);
}
void load_WebKit_WKNavigationDelegate_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
