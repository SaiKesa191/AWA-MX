#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_WebKit_WKContentRuleList_symbols(JSContext*);
@protocol WKContentRuleListInstanceExports<JSExport>
@property (readonly,copy,nonatomic) NSString * identifier;
@end
@protocol WKContentRuleListClassExports<JSExport>
@end
#pragma clang diagnostic pop