#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_WebKit_WKProcessPool_symbols(JSContext*);
@protocol WKProcessPoolInstanceExports<JSExport, NSSecureCodingInstanceExports_>
@end
@protocol WKProcessPoolClassExports<JSExport, NSSecureCodingClassExports_>
@end
#pragma clang diagnostic pop