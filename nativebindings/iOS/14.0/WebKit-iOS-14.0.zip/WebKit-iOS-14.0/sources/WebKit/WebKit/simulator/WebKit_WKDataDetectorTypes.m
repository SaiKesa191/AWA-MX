#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
static void addProtocols()
{
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
	context[@"WKDataDetectorTypeNone"] = @0UL;
	context[@"WKDataDetectorTypePhoneNumber"] = @1UL;
	context[@"WKDataDetectorTypeLink"] = @2UL;
	context[@"WKDataDetectorTypeAddress"] = @4UL;
	context[@"WKDataDetectorTypeCalendarEvent"] = @8UL;
	context[@"WKDataDetectorTypeTrackingNumber"] = @16UL;
	context[@"WKDataDetectorTypeFlightNumber"] = @32UL;
	context[@"WKDataDetectorTypeLookupSuggestion"] = @64UL;
	context[@"WKDataDetectorTypeAll"] = @-1UL;
	context[@"WKDataDetectorTypeSpotlightSuggestion"] = @64UL;

}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
}
void load_WebKit_WKDataDetectorTypes_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
