#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_WebKit_WKPreviewElementInfo_symbols(JSContext*);
@protocol WKPreviewElementInfoInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (readonly,nonatomic) NSURL * linkURL;
@end
@protocol WKPreviewElementInfoClassExports<JSExport, NSCopyingClassExports_>
@end
#pragma clang diagnostic pop