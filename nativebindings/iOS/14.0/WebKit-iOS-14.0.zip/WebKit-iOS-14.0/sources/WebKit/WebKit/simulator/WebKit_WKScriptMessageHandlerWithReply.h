#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_WebKit_WKScriptMessageHandlerWithReply_symbols(JSContext*);
@protocol WKScriptMessageHandlerWithReplyInstanceExports_<JSExport, NSObjectInstanceExports_>
JSExportAs(userContentControllerDidReceiveScriptMessageReplyHandler,
-(void) jsuserContentController: (WKUserContentController *) userContentController didReceiveScriptMessage: (WKScriptMessage *) message replyHandler: (JSValue *) replyHandler );
@end
@protocol WKScriptMessageHandlerWithReplyClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop