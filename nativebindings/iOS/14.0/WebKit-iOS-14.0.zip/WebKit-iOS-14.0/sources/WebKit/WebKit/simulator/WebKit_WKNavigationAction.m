#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
static void addProtocols()
{
	class_addProtocol([WKNavigationAction class], @protocol(WKNavigationActionInstanceExports));
	class_addProtocol([WKNavigationAction class], @protocol(WKNavigationActionClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
	context[@"WKNavigationTypeLinkActivated"] = @0L;
	context[@"WKNavigationTypeFormSubmitted"] = @1L;
	context[@"WKNavigationTypeBackForward"] = @2L;
	context[@"WKNavigationTypeReload"] = @3L;
	context[@"WKNavigationTypeFormResubmitted"] = @4L;
	context[@"WKNavigationTypeOther"] = @-1L;

}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
}
void load_WebKit_WKNavigationAction_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
