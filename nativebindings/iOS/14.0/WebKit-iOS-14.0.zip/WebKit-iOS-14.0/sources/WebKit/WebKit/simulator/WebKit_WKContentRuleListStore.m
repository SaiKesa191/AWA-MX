#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
@implementation WKContentRuleListStore (Exports)
-(void) jslookUpContentRuleListForIdentifier: (NSString *) identifier completionHandler: (JSValue *) completionHandler 
{
	void (^ completionHandler_)(WKContentRuleList *, NSError *) = nil;
	if (!completionHandler.isUndefined) {
		completionHandler_ = ^void(WKContentRuleList * arg0, NSError * arg1) {
			JSContext* __jsContext = completionHandler.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: (arg0 ? [JSValue valueWithObject: arg0 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			[parameters addObject: (arg1 ? [JSValue valueWithObject: arg1 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			callJSFunction(__jsContext, completionHandler, self, parameters);
		};
	}
	[self lookUpContentRuleListForIdentifier: identifier completionHandler: completionHandler_ ];
}
-(void) jsgetAvailableContentRuleListIdentifiers: (JSValue *) completionHandler 
{
	void (^ completionHandler_)(NSArray  *) = nil;
	if (!completionHandler.isUndefined) {
		completionHandler_ = ^void(NSArray * arg0) {
			JSContext* __jsContext = completionHandler.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: (arg0 ? [JSValue valueWithObject: arg0 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			callJSFunction(__jsContext, completionHandler, self, parameters);
		};
	}
	[self getAvailableContentRuleListIdentifiers: completionHandler_ ];
}
-(void) jscompileContentRuleListForIdentifier: (NSString *) identifier encodedContentRuleList: (NSString *) encodedContentRuleList completionHandler: (JSValue *) completionHandler 
{
	void (^ completionHandler_)(WKContentRuleList *, NSError *) = nil;
	if (!completionHandler.isUndefined) {
		completionHandler_ = ^void(WKContentRuleList * arg0, NSError * arg1) {
			JSContext* __jsContext = completionHandler.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: (arg0 ? [JSValue valueWithObject: arg0 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			[parameters addObject: (arg1 ? [JSValue valueWithObject: arg1 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			callJSFunction(__jsContext, completionHandler, self, parameters);
		};
	}
	[self compileContentRuleListForIdentifier: identifier encodedContentRuleList: encodedContentRuleList completionHandler: completionHandler_ ];
}
-(void) jsremoveContentRuleListForIdentifier: (NSString *) identifier completionHandler: (JSValue *) completionHandler 
{
	void (^ completionHandler_)(NSError *) = nil;
	if (!completionHandler.isUndefined) {
		completionHandler_ = ^void(NSError * arg0) {
			JSContext* __jsContext = completionHandler.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: (arg0 ? [JSValue valueWithObject: arg0 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			callJSFunction(__jsContext, completionHandler, self, parameters);
		};
	}
	[self removeContentRuleListForIdentifier: identifier completionHandler: completionHandler_ ];
}
@end
static void addProtocols()
{
	class_addProtocol([WKContentRuleListStore class], @protocol(WKContentRuleListStoreInstanceExports));
	class_addProtocol([WKContentRuleListStore class], @protocol(WKContentRuleListStoreClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
}
void load_WebKit_WKContentRuleListStore_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
